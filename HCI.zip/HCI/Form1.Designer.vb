﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.RF_group = New System.Windows.Forms.GroupBox()
        Me.BT_submit = New System.Windows.Forms.Button()
        Me.lbl_year = New System.Windows.Forms.Label()
        Me.lbl_day = New System.Windows.Forms.Label()
        Me.lbl_month = New System.Windows.Forms.Label()
        Me.lbl_address = New System.Windows.Forms.Label()
        Me.lbl_middle = New System.Windows.Forms.Label()
        Me.lbl_course = New System.Windows.Forms.Label()
        Me.lbl_age = New System.Windows.Forms.Label()
        Me.lbl_Bdate = New System.Windows.Forms.Label()
        Me.lbl_sex = New System.Windows.Forms.Label()
        Me.txt1_address = New System.Windows.Forms.TextBox()
        Me.rbsex_male = New System.Windows.Forms.RadioButton()
        Me.rbsex_female = New System.Windows.Forms.RadioButton()
        Me.cb_Year = New System.Windows.Forms.ComboBox()
        Me.cb_Day = New System.Windows.Forms.ComboBox()
        Me.cb_Month = New System.Windows.Forms.ComboBox()
        Me.CB_age = New System.Windows.Forms.ComboBox()
        Me.txt1_course = New System.Windows.Forms.TextBox()
        Me.txt1_mi = New System.Windows.Forms.TextBox()
        Me.txt1_lastname = New System.Windows.Forms.TextBox()
        Me.lbl_Lastname = New System.Windows.Forms.Label()
        Me.txt1_Firstname = New System.Windows.Forms.MaskedTextBox()
        Me.lbl_Firstname = New System.Windows.Forms.Label()
        Me.RF_group.SuspendLayout()
        Me.SuspendLayout()
        '
        'RF_group
        '
        Me.RF_group.Controls.Add(Me.BT_submit)
        Me.RF_group.Controls.Add(Me.lbl_year)
        Me.RF_group.Controls.Add(Me.lbl_day)
        Me.RF_group.Controls.Add(Me.lbl_month)
        Me.RF_group.Controls.Add(Me.lbl_address)
        Me.RF_group.Controls.Add(Me.lbl_middle)
        Me.RF_group.Controls.Add(Me.lbl_course)
        Me.RF_group.Controls.Add(Me.lbl_age)
        Me.RF_group.Controls.Add(Me.lbl_Bdate)
        Me.RF_group.Controls.Add(Me.lbl_sex)
        Me.RF_group.Controls.Add(Me.txt1_address)
        Me.RF_group.Controls.Add(Me.rbsex_male)
        Me.RF_group.Controls.Add(Me.rbsex_female)
        Me.RF_group.Controls.Add(Me.cb_Year)
        Me.RF_group.Controls.Add(Me.cb_Day)
        Me.RF_group.Controls.Add(Me.cb_Month)
        Me.RF_group.Controls.Add(Me.CB_age)
        Me.RF_group.Controls.Add(Me.txt1_course)
        Me.RF_group.Controls.Add(Me.txt1_mi)
        Me.RF_group.Controls.Add(Me.txt1_lastname)
        Me.RF_group.Controls.Add(Me.lbl_Lastname)
        Me.RF_group.Controls.Add(Me.txt1_Firstname)
        Me.RF_group.Controls.Add(Me.lbl_Firstname)
        Me.RF_group.Location = New System.Drawing.Point(12, 12)
        Me.RF_group.Name = "RF_group"
        Me.RF_group.Size = New System.Drawing.Size(610, 398)
        Me.RF_group.TabIndex = 22
        Me.RF_group.TabStop = False
        Me.RF_group.Text = "RegistrationForm"
        '
        'BT_submit
        '
        Me.BT_submit.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.BT_submit.ForeColor = System.Drawing.Color.DarkSalmon
        Me.BT_submit.Location = New System.Drawing.Point(78, 275)
        Me.BT_submit.Name = "BT_submit"
        Me.BT_submit.Size = New System.Drawing.Size(154, 30)
        Me.BT_submit.TabIndex = 44
        Me.BT_submit.Text = "Submit"
        Me.BT_submit.UseVisualStyleBackColor = False
        '
        'lbl_year
        '
        Me.lbl_year.AutoSize = True
        Me.lbl_year.Location = New System.Drawing.Point(266, 193)
        Me.lbl_year.Name = "lbl_year"
        Me.lbl_year.Size = New System.Drawing.Size(29, 15)
        Me.lbl_year.TabIndex = 43
        Me.lbl_year.Text = "Year"
        '
        'lbl_day
        '
        Me.lbl_day.AutoSize = True
        Me.lbl_day.Location = New System.Drawing.Point(205, 193)
        Me.lbl_day.Name = "lbl_day"
        Me.lbl_day.Size = New System.Drawing.Size(27, 15)
        Me.lbl_day.TabIndex = 42
        Me.lbl_day.Text = "Day"
        '
        'lbl_month
        '
        Me.lbl_month.AutoSize = True
        Me.lbl_month.Location = New System.Drawing.Point(78, 193)
        Me.lbl_month.Name = "lbl_month"
        Me.lbl_month.Size = New System.Drawing.Size(43, 15)
        Me.lbl_month.TabIndex = 41
        Me.lbl_month.Text = "Month"
        '
        'lbl_address
        '
        Me.lbl_address.AutoSize = True
        Me.lbl_address.Location = New System.Drawing.Point(13, 249)
        Me.lbl_address.Name = "lbl_address"
        Me.lbl_address.Size = New System.Drawing.Size(49, 15)
        Me.lbl_address.TabIndex = 40
        Me.lbl_address.Text = "Address"
        '
        'lbl_middle
        '
        Me.lbl_middle.AutoSize = True
        Me.lbl_middle.Location = New System.Drawing.Point(14, 83)
        Me.lbl_middle.Name = "lbl_middle"
        Me.lbl_middle.Size = New System.Drawing.Size(27, 15)
        Me.lbl_middle.TabIndex = 39
        Me.lbl_middle.Text = "M.I."
        '
        'lbl_course
        '
        Me.lbl_course.AutoSize = True
        Me.lbl_course.Location = New System.Drawing.Point(14, 112)
        Me.lbl_course.Name = "lbl_course"
        Me.lbl_course.Size = New System.Drawing.Size(44, 15)
        Me.lbl_course.TabIndex = 38
        Me.lbl_course.Text = "Course"
        '
        'lbl_age
        '
        Me.lbl_age.AutoSize = True
        Me.lbl_age.Location = New System.Drawing.Point(14, 141)
        Me.lbl_age.Name = "lbl_age"
        Me.lbl_age.Size = New System.Drawing.Size(28, 15)
        Me.lbl_age.TabIndex = 37
        Me.lbl_age.Text = "Age"
        '
        'lbl_Bdate
        '
        Me.lbl_Bdate.AutoSize = True
        Me.lbl_Bdate.Location = New System.Drawing.Point(14, 170)
        Me.lbl_Bdate.Name = "lbl_Bdate"
        Me.lbl_Bdate.Size = New System.Drawing.Size(55, 15)
        Me.lbl_Bdate.TabIndex = 36
        Me.lbl_Bdate.Text = "Birthdate"
        '
        'lbl_sex
        '
        Me.lbl_sex.AutoSize = True
        Me.lbl_sex.Location = New System.Drawing.Point(14, 223)
        Me.lbl_sex.Name = "lbl_sex"
        Me.lbl_sex.Size = New System.Drawing.Size(25, 15)
        Me.lbl_sex.TabIndex = 35
        Me.lbl_sex.Text = "Sex"
        '
        'txt1_address
        '
        Me.txt1_address.Location = New System.Drawing.Point(78, 246)
        Me.txt1_address.Name = "txt1_address"
        Me.txt1_address.Size = New System.Drawing.Size(290, 23)
        Me.txt1_address.TabIndex = 34
        '
        'rbsex_male
        '
        Me.rbsex_male.AutoSize = True
        Me.rbsex_male.Location = New System.Drawing.Point(181, 221)
        Me.rbsex_male.Name = "rbsex_male"
        Me.rbsex_male.Size = New System.Drawing.Size(51, 19)
        Me.rbsex_male.TabIndex = 33
        Me.rbsex_male.TabStop = True
        Me.rbsex_male.Text = "Male"
        Me.rbsex_male.UseVisualStyleBackColor = True
        '
        'rbsex_female
        '
        Me.rbsex_female.AutoSize = True
        Me.rbsex_female.Location = New System.Drawing.Point(78, 221)
        Me.rbsex_female.Name = "rbsex_female"
        Me.rbsex_female.Size = New System.Drawing.Size(63, 19)
        Me.rbsex_female.TabIndex = 32
        Me.rbsex_female.TabStop = True
        Me.rbsex_female.Text = "Female"
        Me.rbsex_female.UseVisualStyleBackColor = True
        '
        'cb_Year
        '
        Me.cb_Year.FormattingEnabled = True
        Me.cb_Year.Items.AddRange(New Object() {"1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022"})
        Me.cb_Year.Location = New System.Drawing.Point(266, 167)
        Me.cb_Year.Name = "cb_Year"
        Me.cb_Year.Size = New System.Drawing.Size(102, 23)
        Me.cb_Year.TabIndex = 31
        '
        'cb_Day
        '
        Me.cb_Day.FormattingEnabled = True
        Me.cb_Day.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        Me.cb_Day.Location = New System.Drawing.Point(205, 167)
        Me.cb_Day.Name = "cb_Day"
        Me.cb_Day.Size = New System.Drawing.Size(55, 23)
        Me.cb_Day.TabIndex = 30
        '
        'cb_Month
        '
        Me.cb_Month.FormattingEnabled = True
        Me.cb_Month.Items.AddRange(New Object() {"JAN", "FEB", "MAR", "APRIL", "MAY", "JUNE", "JULY", "AUG", "SEPT", "OCT", "NOV", "DEC"})
        Me.cb_Month.Location = New System.Drawing.Point(78, 167)
        Me.cb_Month.Name = "cb_Month"
        Me.cb_Month.Size = New System.Drawing.Size(121, 23)
        Me.cb_Month.TabIndex = 29
        '
        'CB_age
        '
        Me.CB_age.FormattingEnabled = True
        Me.CB_age.Items.AddRange(New Object() {"15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50"})
        Me.CB_age.Location = New System.Drawing.Point(78, 138)
        Me.CB_age.Name = "CB_age"
        Me.CB_age.Size = New System.Drawing.Size(37, 23)
        Me.CB_age.TabIndex = 28
        '
        'txt1_course
        '
        Me.txt1_course.Location = New System.Drawing.Point(78, 109)
        Me.txt1_course.Name = "txt1_course"
        Me.txt1_course.Size = New System.Drawing.Size(100, 23)
        Me.txt1_course.TabIndex = 27
        '
        'txt1_mi
        '
        Me.txt1_mi.Location = New System.Drawing.Point(78, 80)
        Me.txt1_mi.Name = "txt1_mi"
        Me.txt1_mi.Size = New System.Drawing.Size(37, 23)
        Me.txt1_mi.TabIndex = 26
        '
        'txt1_lastname
        '
        Me.txt1_lastname.Location = New System.Drawing.Point(78, 51)
        Me.txt1_lastname.Name = "txt1_lastname"
        Me.txt1_lastname.Size = New System.Drawing.Size(100, 23)
        Me.txt1_lastname.TabIndex = 25
        '
        'lbl_Lastname
        '
        Me.lbl_Lastname.AutoSize = True
        Me.lbl_Lastname.Location = New System.Drawing.Point(13, 54)
        Me.lbl_Lastname.Name = "lbl_Lastname"
        Me.lbl_Lastname.Size = New System.Drawing.Size(58, 15)
        Me.lbl_Lastname.TabIndex = 24
        Me.lbl_Lastname.Text = "Lastname"
        '
        'txt1_Firstname
        '
        Me.txt1_Firstname.Location = New System.Drawing.Point(78, 22)
        Me.txt1_Firstname.Name = "txt1_Firstname"
        Me.txt1_Firstname.Size = New System.Drawing.Size(100, 23)
        Me.txt1_Firstname.TabIndex = 23
        '
        'lbl_Firstname
        '
        Me.lbl_Firstname.AutoSize = True
        Me.lbl_Firstname.Location = New System.Drawing.Point(13, 25)
        Me.lbl_Firstname.Name = "lbl_Firstname"
        Me.lbl_Firstname.Size = New System.Drawing.Size(59, 15)
        Me.lbl_Firstname.TabIndex = 22
        Me.lbl_Firstname.Text = "Firstname"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.RF_group)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.RF_group.ResumeLayout(False)
        Me.RF_group.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents RF_group As GroupBox
    Friend WithEvents BT_submit As Button
    Friend WithEvents lbl_year As Label
    Friend WithEvents lbl_day As Label
    Friend WithEvents lbl_month As Label
    Friend WithEvents lbl_address As Label
    Friend WithEvents lbl_middle As Label
    Friend WithEvents lbl_course As Label
    Friend WithEvents lbl_age As Label
    Friend WithEvents lbl_Bdate As Label
    Friend WithEvents lbl_sex As Label
    Friend WithEvents txt1_address As TextBox
    Friend WithEvents rbsex_male As RadioButton
    Friend WithEvents rbsex_female As RadioButton
    Friend WithEvents cb_Year As ComboBox
    Friend WithEvents cb_Day As ComboBox
    Friend WithEvents cb_Month As ComboBox
    Friend WithEvents CB_age As ComboBox
    Friend WithEvents txt1_course As TextBox
    Friend WithEvents txt1_mi As TextBox
    Friend WithEvents txt1_lastname As TextBox
    Friend WithEvents lbl_Lastname As Label
    Friend WithEvents txt1_Firstname As MaskedTextBox
    Friend WithEvents lbl_Firstname As Label
End Class
