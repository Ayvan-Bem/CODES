﻿Public Class Form2
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles BT_home.Click
        Form1.Show()
        Me.Hide()
    End Sub
End Class