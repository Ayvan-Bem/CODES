﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles BT_submit.Click
        Dim msg As DialogResult
        msg = MessageBox.Show("Are you sure you want to submit?", "Prompt", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If DialogResult.Yes Then
            Form2.txt2_Firstname.Text = txt1_Firstname.Text
            Form2.txt2_lastname.Text = txt1_lastname.Text
            Form2.txt2_mi.Text = txt1_mi.Text
            Form2.txt2_course.Text = txt1_course.Text
            Form2.txt2_age.Text = CB_age.Text
            Form2.txt2_bday.Text = cb_Month.Text + "/" + cb_Day.Text + "/" + cb_Year.Text
            If rbsex_female.Checked = True Then
                Form2.txt2_sex.Text = "Female"
            ElseIf rbsex_male.Checked = True Then
                Form2.txt2_sex.Text = "Male"
            End If
            Form2.txt2_address.Text = txt1_address.Text

            Form2.Show()
            Me.Hide()
        Else
            Form2.txt2_Firstname.Text = " "
            Form2.txt2_lastname.Text = " "
            Form2.txt2_mi.Text = " "
            Form2.txt2_course.Text = " "
            Form2.txt2_age.Text = " "
            Form2.txt2_bday.Text = " "
            Form2.txt2_sex.Text = " "
            Form2.txt2_address.Text = " "
        End If

    End Sub

End Class
