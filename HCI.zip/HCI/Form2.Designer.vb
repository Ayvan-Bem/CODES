﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DF_group = New System.Windows.Forms.GroupBox()
        Me.txt2_bday = New System.Windows.Forms.TextBox()
        Me.txt2_age = New System.Windows.Forms.TextBox()
        Me.txt2_sex = New System.Windows.Forms.TextBox()
        Me.lbl_address = New System.Windows.Forms.Label()
        Me.lbl_middle = New System.Windows.Forms.Label()
        Me.lbl_course = New System.Windows.Forms.Label()
        Me.lbl_age = New System.Windows.Forms.Label()
        Me.lbl_Bdate = New System.Windows.Forms.Label()
        Me.lbl_sex = New System.Windows.Forms.Label()
        Me.txt2_address = New System.Windows.Forms.TextBox()
        Me.txt2_course = New System.Windows.Forms.TextBox()
        Me.txt2_mi = New System.Windows.Forms.TextBox()
        Me.txt2_lastname = New System.Windows.Forms.TextBox()
        Me.lbl_Lastname = New System.Windows.Forms.Label()
        Me.txt2_Firstname = New System.Windows.Forms.MaskedTextBox()
        Me.lbl_Firstname = New System.Windows.Forms.Label()
        Me.BT_home = New System.Windows.Forms.Button()
        Me.DF_group.SuspendLayout()
        Me.SuspendLayout()
        '
        'DF_group
        '
        Me.DF_group.Controls.Add(Me.BT_home)
        Me.DF_group.Controls.Add(Me.txt2_bday)
        Me.DF_group.Controls.Add(Me.txt2_age)
        Me.DF_group.Controls.Add(Me.txt2_sex)
        Me.DF_group.Controls.Add(Me.lbl_address)
        Me.DF_group.Controls.Add(Me.lbl_middle)
        Me.DF_group.Controls.Add(Me.lbl_course)
        Me.DF_group.Controls.Add(Me.lbl_age)
        Me.DF_group.Controls.Add(Me.lbl_Bdate)
        Me.DF_group.Controls.Add(Me.lbl_sex)
        Me.DF_group.Controls.Add(Me.txt2_address)
        Me.DF_group.Controls.Add(Me.txt2_course)
        Me.DF_group.Controls.Add(Me.txt2_mi)
        Me.DF_group.Controls.Add(Me.txt2_lastname)
        Me.DF_group.Controls.Add(Me.lbl_Lastname)
        Me.DF_group.Controls.Add(Me.txt2_Firstname)
        Me.DF_group.Controls.Add(Me.lbl_Firstname)
        Me.DF_group.Location = New System.Drawing.Point(12, 12)
        Me.DF_group.Name = "DF_group"
        Me.DF_group.Size = New System.Drawing.Size(525, 362)
        Me.DF_group.TabIndex = 47
        Me.DF_group.TabStop = False
        Me.DF_group.Text = "DisplayForm"
        '
        'txt2_bday
        '
        Me.txt2_bday.Location = New System.Drawing.Point(76, 188)
        Me.txt2_bday.Name = "txt2_bday"
        Me.txt2_bday.Size = New System.Drawing.Size(100, 23)
        Me.txt2_bday.TabIndex = 62
        '
        'txt2_age
        '
        Me.txt2_age.Location = New System.Drawing.Point(76, 161)
        Me.txt2_age.Name = "txt2_age"
        Me.txt2_age.Size = New System.Drawing.Size(37, 23)
        Me.txt2_age.TabIndex = 61
        '
        'txt2_sex
        '
        Me.txt2_sex.Location = New System.Drawing.Point(76, 217)
        Me.txt2_sex.Name = "txt2_sex"
        Me.txt2_sex.Size = New System.Drawing.Size(37, 23)
        Me.txt2_sex.TabIndex = 60
        '
        'lbl_address
        '
        Me.lbl_address.AutoSize = True
        Me.lbl_address.Location = New System.Drawing.Point(11, 253)
        Me.lbl_address.Name = "lbl_address"
        Me.lbl_address.Size = New System.Drawing.Size(49, 15)
        Me.lbl_address.TabIndex = 59
        Me.lbl_address.Text = "Address"
        '
        'lbl_middle
        '
        Me.lbl_middle.AutoSize = True
        Me.lbl_middle.Location = New System.Drawing.Point(12, 106)
        Me.lbl_middle.Name = "lbl_middle"
        Me.lbl_middle.Size = New System.Drawing.Size(27, 15)
        Me.lbl_middle.TabIndex = 58
        Me.lbl_middle.Text = "M.I."
        '
        'lbl_course
        '
        Me.lbl_course.AutoSize = True
        Me.lbl_course.Location = New System.Drawing.Point(12, 135)
        Me.lbl_course.Name = "lbl_course"
        Me.lbl_course.Size = New System.Drawing.Size(44, 15)
        Me.lbl_course.TabIndex = 57
        Me.lbl_course.Text = "Course"
        '
        'lbl_age
        '
        Me.lbl_age.AutoSize = True
        Me.lbl_age.Location = New System.Drawing.Point(12, 164)
        Me.lbl_age.Name = "lbl_age"
        Me.lbl_age.Size = New System.Drawing.Size(28, 15)
        Me.lbl_age.TabIndex = 56
        Me.lbl_age.Text = "Age"
        '
        'lbl_Bdate
        '
        Me.lbl_Bdate.AutoSize = True
        Me.lbl_Bdate.Location = New System.Drawing.Point(11, 196)
        Me.lbl_Bdate.Name = "lbl_Bdate"
        Me.lbl_Bdate.Size = New System.Drawing.Size(55, 15)
        Me.lbl_Bdate.TabIndex = 55
        Me.lbl_Bdate.Text = "Birthdate"
        '
        'lbl_sex
        '
        Me.lbl_sex.AutoSize = True
        Me.lbl_sex.Location = New System.Drawing.Point(15, 225)
        Me.lbl_sex.Name = "lbl_sex"
        Me.lbl_sex.Size = New System.Drawing.Size(25, 15)
        Me.lbl_sex.TabIndex = 54
        Me.lbl_sex.Text = "Sex"
        '
        'txt2_address
        '
        Me.txt2_address.Location = New System.Drawing.Point(76, 246)
        Me.txt2_address.Name = "txt2_address"
        Me.txt2_address.Size = New System.Drawing.Size(275, 23)
        Me.txt2_address.TabIndex = 53
        '
        'txt2_course
        '
        Me.txt2_course.Location = New System.Drawing.Point(76, 132)
        Me.txt2_course.Name = "txt2_course"
        Me.txt2_course.Size = New System.Drawing.Size(100, 23)
        Me.txt2_course.TabIndex = 52
        '
        'txt2_mi
        '
        Me.txt2_mi.Location = New System.Drawing.Point(76, 103)
        Me.txt2_mi.Name = "txt2_mi"
        Me.txt2_mi.Size = New System.Drawing.Size(37, 23)
        Me.txt2_mi.TabIndex = 51
        '
        'txt2_lastname
        '
        Me.txt2_lastname.Location = New System.Drawing.Point(76, 74)
        Me.txt2_lastname.Name = "txt2_lastname"
        Me.txt2_lastname.Size = New System.Drawing.Size(100, 23)
        Me.txt2_lastname.TabIndex = 50
        '
        'lbl_Lastname
        '
        Me.lbl_Lastname.AutoSize = True
        Me.lbl_Lastname.Location = New System.Drawing.Point(11, 77)
        Me.lbl_Lastname.Name = "lbl_Lastname"
        Me.lbl_Lastname.Size = New System.Drawing.Size(58, 15)
        Me.lbl_Lastname.TabIndex = 49
        Me.lbl_Lastname.Text = "Lastname"
        '
        'txt2_Firstname
        '
        Me.txt2_Firstname.Location = New System.Drawing.Point(76, 45)
        Me.txt2_Firstname.Name = "txt2_Firstname"
        Me.txt2_Firstname.Size = New System.Drawing.Size(100, 23)
        Me.txt2_Firstname.TabIndex = 48
        '
        'lbl_Firstname
        '
        Me.lbl_Firstname.AutoSize = True
        Me.lbl_Firstname.Location = New System.Drawing.Point(11, 48)
        Me.lbl_Firstname.Name = "lbl_Firstname"
        Me.lbl_Firstname.Size = New System.Drawing.Size(59, 15)
        Me.lbl_Firstname.TabIndex = 47
        Me.lbl_Firstname.Text = "Firstname"
        '
        'BT_home
        '
        Me.BT_home.BackColor = System.Drawing.Color.Coral
        Me.BT_home.ForeColor = System.Drawing.Color.Black
        Me.BT_home.Location = New System.Drawing.Point(76, 284)
        Me.BT_home.Name = "BT_home"
        Me.BT_home.Size = New System.Drawing.Size(149, 28)
        Me.BT_home.TabIndex = 63
        Me.BT_home.Text = "Home"
        Me.BT_home.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.DF_group)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.DF_group.ResumeLayout(False)
        Me.DF_group.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DF_group As GroupBox
    Friend WithEvents BT_home As Button
    Friend WithEvents txt2_bday As TextBox
    Friend WithEvents txt2_age As TextBox
    Friend WithEvents txt2_sex As TextBox
    Friend WithEvents lbl_address As Label
    Friend WithEvents lbl_middle As Label
    Friend WithEvents lbl_course As Label
    Friend WithEvents lbl_age As Label
    Friend WithEvents lbl_Bdate As Label
    Friend WithEvents lbl_sex As Label
    Friend WithEvents txt2_address As TextBox
    Friend WithEvents txt2_course As TextBox
    Friend WithEvents txt2_mi As TextBox
    Friend WithEvents txt2_lastname As TextBox
    Friend WithEvents lbl_Lastname As Label
    Friend WithEvents txt2_Firstname As MaskedTextBox
    Friend WithEvents lbl_Firstname As Label
End Class
