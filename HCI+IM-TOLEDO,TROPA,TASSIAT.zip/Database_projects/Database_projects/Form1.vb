﻿Imports MySql.Data.MySqlClient
Public Class Form1

    Dim str As String = "server=localhost; uid=root; pwd=; database=hcim"
    Dim con As New MySqlConnection(str)
    Dim inttotal1 As Integer
    Dim inttotal2 As Integer
    Dim Total As Integer
    Dim price As Integer
    Dim quan As Integer
    Dim price1 As Integer
    Dim quan1 As Integer


    Shadows Sub Load()
        Dim query As String = "SELECT * FROM `tbl_order`"
        Dim adpt As New MySqlDataAdapter(query, con)
        Dim ds As New DataSet()
        adpt.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        con.Close()
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Load()
        con.Close()
    End Sub


    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow
        Try
            TextBox2.Text = row.Cells(0).Value.ToString()
            TextBox1.Text = row.Cells(1).Value.ToString()
            ComboBox1.Text = row.Cells(2).Value.ToString()
            ComboBox3.Text = row.Cells(3).Value.ToString()
            ComboBox2.Text = row.Cells(4).Value.ToString()
            ComboBox4.Text = row.Cells(5).Value.ToString()
            TextBox4.Text = row.Cells(6).Value.ToString()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedItem = "Hotdog on Stick" Then
            price = 30
        ElseIf ComboBox1.SelectedItem = "Hotdog Sandwich" Then
            price = 40
        ElseIf ComboBox1.SelectedItem = "Burger" Then
            price = 50
        ElseIf ComboBox1.SelectedItem = "French Fries" Then
            price = 30
        ElseIf ComboBox1.SelectedItem = "Popcorn" Then
            price = 40
        ElseIf ComboBox1.SelectedItem = "Mentol Candy" Then
            price = 5
        End If

        If ComboBox3.SelectedItem = 1 Then
            quan = 1
        ElseIf ComboBox3.SelectedItem = 2 Then
            quan = 2
        ElseIf ComboBox3.SelectedItem = 3 Then
            quan = 3
        ElseIf ComboBox3.SelectedItem = 4 Then
            quan = 4
        ElseIf ComboBox3.SelectedItem = 5 Then
            quan = 5
        ElseIf ComboBox3.SelectedItem = 6 Then
            quan = 6
        End If

        If ComboBox2.SelectedItem = "Coke" Then
            price1 = 20
        ElseIf ComboBox2.SelectedItem = "Royal" Then
            price1 = 20
        ElseIf ComboBox2.SelectedItem = "Pepsi" Then
            price1 = 20
        ElseIf ComboBox1.SelectedItem = "Water" Then
            price1 = 15
        ElseIf ComboBox1.SelectedItem = "Slurpy" Then
            price1 = 25
        ElseIf ComboBox1.SelectedItem = "Float" Then
            price1 = 35
        End If

        If ComboBox4.SelectedItem = 1 Then
            quan1 = 1
        ElseIf ComboBox4.SelectedItem = 2 Then
            quan1 = 2
        ElseIf ComboBox4.SelectedItem = 3 Then
            quan1 = 3
        ElseIf ComboBox4.SelectedItem = 4 Then
            quan1 = 4
        ElseIf ComboBox4.SelectedItem = 5 Then
            quan1 = 5
        ElseIf ComboBox4.SelectedItem = 6 Then
            quan1 = 6
        End If

        inttotal1 = price * quan
        inttotal2 = price1 * quan1


        TextBox4.Text = inttotal1 + inttotal2

        Dim cmd As MySqlCommand
        con.Open()

        Try
            cmd = con.CreateCommand()
            cmd.CommandText = "INSERT INTO `tbl_order`(`Sit_No.`, `Food`, `Food_Quantity`, `Beverage`, `Bev_Quantity`, `Total`) VALUES (@Sit_No.,@Food,@Food_Quantity, @Beverage, @Bev_Quantity, @Total)"

            cmd.Parameters.AddWithValue("@Sit_No.", TextBox1.Text)
            cmd.Parameters.AddWithValue("@Food", ComboBox1.Text)
            cmd.Parameters.AddWithValue("@Food_Quantity", ComboBox3.Text)
            cmd.Parameters.AddWithValue("@Beverage", ComboBox2.Text)
            cmd.Parameters.AddWithValue("@Bev_Quantity", ComboBox4.Text)
            cmd.Parameters.AddWithValue("@Total", TextBox4.Text)
            cmd.ExecuteNonQuery()
            Load()
            MessageBox.Show("Order Added!")
        Catch ex As Exception

        End Try
        con.Close()



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) 
        Dim sum As Double
        For i As Integer = 0 To DataGridView1.RowCount - 1
            sum += DataGridView1.Rows(i).Cells(6).Value
        Next
        DataGridView1.Rows.Add(Nothing, Nothing, Nothing, Nothing, Nothing, "total", sum)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If ComboBox1.SelectedItem = "Hotdog on Stick" Then
            price = 30
        ElseIf ComboBox1.SelectedItem = "Hotdog Sandwich" Then
            price = 40
        ElseIf ComboBox1.SelectedItem = "Burger" Then
            price = 50
        ElseIf ComboBox1.SelectedItem = "French Fries" Then
            price = 30
        ElseIf ComboBox1.SelectedItem = "Popcorn" Then
            price = 40
        ElseIf ComboBox1.SelectedItem = "Mentol Candy" Then
            price = 5
        End If

        If ComboBox3.SelectedItem = 1 Then
            quan = 1
        ElseIf ComboBox3.SelectedItem = 2 Then
            quan = 2
        ElseIf ComboBox3.SelectedItem = 3 Then
            quan = 3
        ElseIf ComboBox3.SelectedItem = 4 Then
            quan = 4
        ElseIf ComboBox3.SelectedItem = 5 Then
            quan = 5
        ElseIf ComboBox3.SelectedItem = 6 Then
            quan = 6
        End If

        If ComboBox2.SelectedItem = "Coke" Then
            price1 = 20
        ElseIf ComboBox2.SelectedItem = "Royal" Then
            price1 = 20
        ElseIf ComboBox2.SelectedItem = "Pepsi" Then
            price1 = 20
        ElseIf ComboBox1.SelectedItem = "Water" Then
            price1 = 15
        ElseIf ComboBox1.SelectedItem = "Slurpy" Then
            price1 = 25
        ElseIf ComboBox1.SelectedItem = "Float" Then
            price1 = 35
        End If

        If ComboBox4.SelectedItem = 1 Then
            quan1 = 1
        ElseIf ComboBox4.SelectedItem = 2 Then
            quan1 = 2
        ElseIf ComboBox4.SelectedItem = 3 Then
            quan1 = 3
        ElseIf ComboBox4.SelectedItem = 4 Then
            quan1 = 4
        ElseIf ComboBox4.SelectedItem = 5 Then
            quan1 = 5
        ElseIf ComboBox4.SelectedItem = 6 Then
            quan1 = 6
        End If

        inttotal1 = price * quan
        inttotal2 = price1 * quan1

        TextBox4.Text = inttotal1 + inttotal2
        Dim cmd As MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand()
            cmd.CommandText = "UPDATE `tbl_order` SET `Order_No.`= @Order_No.,`Sit_No.` = @Sit_No., `Food`= @Food, `Food_Quantity`= @Food_Quantity, `Beverage`= @Beverage, `Bev_Quantity`= @Bev_Quantity, `Total`= @Total WHERE `Order_No.`= @Order_No.;"
            cmd.Parameters.AddWithValue("@Order_No.", TextBox2.Text)
            cmd.Parameters.AddWithValue("@Sit_No.", TextBox1.Text)
            cmd.Parameters.AddWithValue("@Food", ComboBox1.Text)
            cmd.Parameters.AddWithValue("@Food_Quantity", ComboBox3.Text)
            cmd.Parameters.AddWithValue("@Beverage", ComboBox2.Text)
            cmd.Parameters.AddWithValue("@Bev_Quantity", ComboBox4.Text)
            cmd.Parameters.AddWithValue("@Total", TextBox4.Text)
            cmd.ExecuteNonQuery()
            Load()
            MessageBox.Show("Order Updated!")
        Catch ex As Exception

        End Try
        con.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim cmd As MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand()
            cmd.CommandText = "DELETE FROM `tbl_order` WHERE `Order_No.` = @Order_No."
            cmd.Parameters.AddWithValue("@Order_No.", TextBox2.Text)
            cmd.ExecuteNonQuery()
            Load()
            MessageBox.Show("Order Canceled")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox4.Clear()
        MessageBox.Show("Thankyou For Ordering, Next Customer Please!")

    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Dim adapter As MySqlDataAdapter
        Dim ds As New DataSet
        Try
            con.Open()
            adapter = New MySqlDataAdapter("SELECT * FROM `tbl_order` WHERE `Order_No.` like '%" & TextBox2.Text & "%' ", con)
            adapter.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            con.Close()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox4.Clear()

        Catch ex As Exception

        End Try
    End Sub
End Class